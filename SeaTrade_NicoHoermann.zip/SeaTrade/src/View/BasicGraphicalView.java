package View;

public abstract class BasicGraphicalView implements IView {
	
}
