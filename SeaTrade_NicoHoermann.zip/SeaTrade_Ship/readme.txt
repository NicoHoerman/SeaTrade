Commands only work if connected to a company.

Commands:
Recruit 	recruit:seaTradePort:SeaTradeEndpoint:CompanyPort:CompanyEndpoint:ShipName	recruit:8151:localhost
            Example input: recruit:8151:localhost:8080:localhost:TestShip

LoadCargo:	loadcargo:	
UnloadCargo	unloadcargo:
Exit	    exit:
