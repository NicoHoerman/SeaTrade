

Commands
Register	register:CompanyName:SeaTradeServerPort:SeaTradeServerEndpoint:CompanyServerPort
            Example input:	register:TestCompany:8150:localhost:8080
GetHarbours:	harbours:
GetCargos:	    cargos:
GetCompany:	    company:Shows name, deposit, list of ships	
instructShip	instruct:harbour:ShipIndex	
                Example input: instruct:halifax:0
Exit	        exit:
