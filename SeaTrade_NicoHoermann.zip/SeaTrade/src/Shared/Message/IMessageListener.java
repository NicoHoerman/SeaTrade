package Shared.Message;

public interface IMessageListener  {

	void ListenTo(Message message);
}
