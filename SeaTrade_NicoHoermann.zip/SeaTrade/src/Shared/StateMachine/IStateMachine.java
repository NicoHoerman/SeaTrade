package Shared.StateMachine;

public interface IStateMachine {

	public abstract void Run() throws Exception;
}
